import com.aspose.words.*;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2017/2/7.
 */
public class WordDocConverter {

    public WordDocConverter() {}

    public List<WordDocQuestionBean> convertToQuestionList(String filePath) throws Exception {
        List<WordDocQuestionBean> beans = new ArrayList<WordDocQuestionBean>();

        Document doc = new Document(filePath);

        SectionCollection sections = doc.getSections();
        int count = 0;
        for (Section section : sections) {
            count++;
            section = clearFormat(section);
            try {
                WordDocQuestionBean bean = analysisSectionToObj(section);
                if(bean.getType() == WordDocQuestionType.UNKNOWN) continue;
                beans.add(bean);
            } catch (Exception e) {
                throw new Exception(String.format("第%s题, %s", count, e.getMessage()));
            }
        }
        return beans;
    }

    private WordDocQuestionBean analysisSectionToObj(Section section) throws Exception {

        WordDocQuestionBean question = new WordDocQuestionBean();
//        ParagraphCollection paragraphs = section.getBody().getParagraphs();
        NodeCollection nodes = section.getBody().getChildNodes();

//        for( Node child : (Iterable<Node>) nodes) {
//            System.out.println(child.getNodeType());
//        }
        int questionType = WordDocQuestionType.UNKNOWN;
        int index = 0;
        List<Integer> subQuestionsStartAt = new ArrayList<Integer>();
        List<Integer> subQuestionsType = new ArrayList<Integer>();
        // 解析题型
        for (Node node : (Iterable<Node>)nodes) {
            index++;
            // 去除开发版测试数据
            if (node.getText().contains("Evaluation Only")) continue;
            if (node.getText().trim().length() < 1) continue;
            questionType = getQuestionType(node);
            if(questionType == WordDocQuestionType.UNKNOWN) {
                throw new Exception("未指定题型");
            }
            question.setType(questionType);
            break;
        }

        // 解析是否有子题目
        for(int i = index; i < nodes.getCount(); i++) {
            Node node = nodes.get(i);
            int qt = getQuestionType(node);
            if(qt != WordDocQuestionType.UNKNOWN) {
                subQuestionsStartAt.add(i);
                subQuestionsType.add(qt);
            }
        }

        // 分析子题目题型是否合法
        if(questionType != WordDocQuestionType.综合题) {
            for(int type : subQuestionsType) {
                if(type != questionType) {
                    throw new Exception("子题目类型指定错误 : 非综合题不能有多种类型子题目");
                }
            }
        }
        else {
            for(int type : subQuestionsType) {
                if(type == WordDocQuestionType.综合题) {
                    throw new Exception("子题目类型指定错误 : 子题目类型不能为综合题");
                }
            }
        }

        if(subQuestionsType.size() > 0) {
            // 有子题目的
            // 分析子题目起止位置
            int subQuestionCount = 0;

            // 获取题干
            StringBuilder questionBody = new StringBuilder();
            for(int i = index; i < subQuestionsStartAt.get(0); i++) {
                Node node = nodes.get(i);
                questionBody.append(node.toString(SaveFormat.HTML));
            }
            question.setBody(questionBody.toString());

            List<WordDocQuestionBean> subQuestions = new ArrayList<WordDocQuestionBean>();

            for(int startAt : subQuestionsStartAt) {
                int endWith = (subQuestionCount + 1 == subQuestionsStartAt.size()) ?
                        nodes.getCount() :
                        subQuestionsStartAt.get(subQuestionCount + 1);
                subQuestions.add(analysisParagraphsToObj(nodes, startAt, endWith));
                subQuestionCount++;
            }
            question.setSubQuestions(subQuestions);
        }
        else {
            // 无子题目的
            question = analysisParagraphsToObj(nodes, 0, nodes.getCount());
        }

        return question;
    }

    private WordDocQuestionBean analysisParagraphsToObj(NodeCollection nodes,
                                                        Integer startIndex, Integer endIndex) throws Exception {
        WordDocQuestionBean question = new WordDocQuestionBean();
        StringBuilder questionBody = new StringBuilder();
        StringBuilder questionAnswer = new StringBuilder();

        int state = 0;
        for(int i = startIndex; i < endIndex; i++) {
            Node node = nodes.get(i);
            if(state == 0) {
                // 读取题型
                if (node.getText().trim().length() < 1) continue;
                if (node.getText().contains("Evaluation Only")) continue;
                question.setType(getQuestionType(node));
                if(question.getType() == WordDocQuestionType.UNKNOWN) {
                    throw new Exception("题型错误");
                }
                state = 1;
            }
            else if(state == 1) {
                // 读取题干
                if(node.getText().trim().equals("答案")) {
                    state = 2;
                    continue;
                }
                questionBody.append(node.toString(SaveFormat.HTML));
            }
            else if(state == 2) {
                // 读取答案
                questionAnswer.append(node.toString(SaveFormat.HTML));
            }
        }
        question.setBody(questionBody.toString());
        question.setAnswer(questionAnswer.toString());

        return question;
    }

    private Integer getQuestionType(Node node) {
        if (node.getText().trim().equals("选择题")) {
            return WordDocQuestionType.选择题;
        } else if (node.getText().trim().equals("填空题")) {
            return WordDocQuestionType.填空题;
        } else if (node.getText().trim().equals("解答题")) {
            return WordDocQuestionType.解答题;
        } else if (node.getText().trim().equals("综合题")) {
            return WordDocQuestionType.综合题;
        } else if (node.getText().trim().equals("作文题")) {
            return WordDocQuestionType.作文题;
        }
        return WordDocQuestionType.UNKNOWN;
    }

    private Section clearFormat(Section section) {
        HeaderFooter footer;
        footer = section.getHeadersFooters().getByHeaderFooterType(HeaderFooterType.FOOTER_FIRST);
        if (footer != null)
            footer.remove();
        footer = section.getHeadersFooters().getByHeaderFooterType(HeaderFooterType.FOOTER_PRIMARY);
        if (footer != null)
            footer.remove();
        footer = section.getHeadersFooters().getByHeaderFooterType(HeaderFooterType.FOOTER_EVEN);
        if (footer != null)
            footer.remove();
        footer = section.getHeadersFooters().getByHeaderFooterType(HeaderFooterType.HEADER_EVEN);
        if (footer != null)
            footer.remove();
        footer = section.getHeadersFooters().getByHeaderFooterType(HeaderFooterType.HEADER_FIRST);
        if (footer != null)
            footer.remove();
        footer = section.getHeadersFooters().getByHeaderFooterType(HeaderFooterType.HEADER_PRIMARY);
        if (footer != null)
            footer.remove();
        return section;
    }

}
