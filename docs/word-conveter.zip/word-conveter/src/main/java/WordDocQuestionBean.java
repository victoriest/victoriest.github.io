import java.util.List;

/**
 * Created by Administrator on 2017/2/7.
 */
public final class WordDocQuestionBean {

    private int type;

    private String body;

    private String answer;

    private String alys;

    private List<WordDocQuestionBean> subQuestions;

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public String getAlys() {
        return alys;
    }

    public void setAlys(String alys) {
        this.alys = alys;
    }

    public List<WordDocQuestionBean> getSubQuestions() {
        return subQuestions;
    }

    public void setSubQuestions(List<WordDocQuestionBean> subQuestions) {
        this.subQuestions = subQuestions;
    }
}
