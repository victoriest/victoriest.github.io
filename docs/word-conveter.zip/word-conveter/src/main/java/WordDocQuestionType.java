/**
 * Created by Administrator on 2017/2/7.
 */
public class WordDocQuestionType {
    public static final Integer UNKNOWN = 0;
    public static final Integer 选择题 = 1;
    public static final Integer 填空题 = 2;
    public static final Integer 解答题 = 3;
    public static final Integer 综合题 = 4;
    public static final Integer 作文题 = 5;
}
