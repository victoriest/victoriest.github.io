import java.io.File;
import java.io.FileWriter;

/**
 * Created by Administrator on 2017/2/2.
 */
public class WordConveterMain {
    public static void main(String[] args) throws Exception {
        WordDocConverter converter = new WordDocConverter();
        File dir = new File(System.getProperty("user.dir"));
        java.util.List<WordDocQuestionBean> list = converter.convertToQuestionList(dir.toString() + File.separator + "formated_doc.docx");

        int i = 0;
        for(WordDocQuestionBean bean : list) {
            FileWriter writer=new FileWriter("converted_"+i+".html");
            writer.write(bean.getBody());
            writer.write("</br>--------------------------</br>");

            if(bean.getSubQuestions() != null && bean.getSubQuestions().size() > 0){
                for(WordDocQuestionBean sub : bean.getSubQuestions()) {
                    writer.write(sub.getBody());
                    writer.write("</br>--------------------------</br>");
                    writer.write(sub.getAnswer());
                    writer.write("</br>--------------------------</br>");
                }
            }
            else {
                writer.write(bean.getAnswer());
                writer.write("</br>--------------------------</br>");
            }
            writer.close();
            i++;
        }
    }

//    public static void main(String[] args) throws Exception {

        //************************************************************************
        // POI导出html
//        InputStream is = new FileInputStream("F:\\poitest\\222.docx");
//        XWPFDocument doc = new XWPFDocument(is);
//
//        // 2) Prepare XHTML options (here we set the IURIResolver to
//        // load images from a "word/media" folder)
//        File imageFolderFile = new File("F:\\poitest\\");
//        XHTMLOptions options = XHTMLOptions.create().URIResolver(
//                new FileURIResolver(imageFolderFile));
//        options.setExtractor(new FileImageExtractor(imageFolderFile));
//        //options.setIgnoreStylesIfUnused(false);
//        //options.setFragment(true);
//
//        // 3) Convert XWPFDocument to XHTML
//        OutputStream out = new FileOutputStream(new File(
//                "F:\\poitest\\222.html"));
//        XHTMLConverter.getInstance().convert(doc, out, options);

//        List<IBodyElement> elms = doc.getBodyElements();
//        for (IBodyElement elm : elms) {
//            System.out.println(String.format("{0} : {1}", elm.getElementType().toString(), elm.getBody().toString()));
//        }
//        List<XWPFParagraph> paras = doc.getParagraphs();
//        for (XWPFParagraph para : paras) {
//            //当前段落的属性
////       CTPPr pr = para.getCTP().getPPr();
//            System.out.println(para.getText());
//        }
//        //获取文档中所有的表格
//        List<XWPFTable> tables = doc.getTables();
//        List<XWPFTableRow> rows;
//        List<XWPFTableCell> cells;
//        for (XWPFTable table : tables) {
//            //表格属性
////       CTTblPr pr = table.getCTTbl().getTblPr();
//            //获取表格对应的行
//            rows = table.getRows();
//            for (XWPFTableRow row : rows) {
//                //获取行对应的单元格
//                cells = row.getTableCells();
//                for (XWPFTableCell cell : cells) {
//                    System.out.println(cell.getText());
//                }
//            }
//        }
//        is.close();
//    }

}
