#### 本示例工程演示了格式化word文档通过aspose对文档进行解析, 输出成java对象和html的过程

* word文档的java对象定义于WordDocQuestionBean.java文件中
* 格式化word文档规则说明 参见本目录下格式化[word文档规则说明.docx](./格式化word文档规则说明.docx)